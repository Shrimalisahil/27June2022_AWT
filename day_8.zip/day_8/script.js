function alertjs1(){
    alert('hii guys')
}

function promptjs1(){
    prompt('hii enter your name')
}

function confirmjs1(){
    confirm('its all right')
}

console.log('sahil');